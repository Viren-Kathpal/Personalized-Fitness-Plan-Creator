# Import the main function from the gui module
from gui import main

# Check if this script is being run directly (i.e., not being imported)
if __name__ == "__main__":
    # If true, call the main function to start the application
    main()
